/*define
 */

/**
 * Simple view mode service.
 */
define( [ 'app', 'js/appCtxService', 'js/NotyModule' ], function( app ) {
    'use strict';

    var exports = {};

    /**
     * Simple service to change view mode
     *
     * @class SimpleViewModeService
     * @param appCtxService {Object} - App context service
     * @param notyService {Object} - Noty service
     * @memberOf NgServices
     */
    app.service( 'SimpleViewModeService', [ 'appCtxService', 'notyService', function( appCtxService, notyService ){

        /**
         * The possible view modes
         *
         * @member viewModes
         * @memberOf NgControllers.SimpleViewModeService
         */
        var viewModes = [ 'SummaryView', 'ListView', 'TableView', 'TableSummaryView', 'ImageView' ];

        /**
         * Index of the view mode that is currently active
         *
         * @member currentViewModeIdx
         * @memberOf NgControllers.SimpleViewModeService
         */
        var currentViewModeIdx = 0;

        /**
         * Change the view mode
         *
         * @function changeViewMode
         * @param {String} viewMode - (Optional) The name of the view mode to change to
         * @memberOf NgServices.SimpleViewModeService
         */
        this.changeViewMode = function( viewMode ){
            if( viewMode ){
                //If it is not a valid view mode show a warning
                if( viewModes.indexOf( viewMode ) === -1 ) {
                    notyService.showError( 'Unknown view mode ' + viewMode + ' remaining in ' + viewModes[ currentViewModeIdx ] + ' view' );
                    return;
                }
                else {
                    currentViewModeIdx = viewModes.indexOf( viewMode );
                }
            }
            else {
                var currentViewMode = appCtxService.getCtx( 'ViewModeContext.ViewModeContext' );
                currentViewModeIdx = ( viewModes.indexOf( currentViewMode ) + 1 ) % viewModes.length;
            }

            appCtxService.registerCtx( 'ViewModeContext', {
                ViewModeContext: viewModes[ currentViewModeIdx ]
            } );

            notyService.showInfo( 'Changed to ' + viewModes[ currentViewModeIdx ] );
        };

    } ] );

    return {
        moduleServiceNameToInject: 'SimpleViewModeService'
    };

} );