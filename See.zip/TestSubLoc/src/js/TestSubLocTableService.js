//@<COPYRIGHT>@
//==================================================
//Copyright 2017.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/*window
 */

/**
 * Simple column provider service
 */
define( [], function() {
    'use strict';

    var exports = {};
	
	exports.alert = function(text) {
        alert( text );
    };

    /**
     * Load the column configuration into the data provider.
     *
     * @param {Object} dataprovider - the data provider
     */
    exports.loadColumns = function( dataProvider ) {
        dataProvider.columnConfig = {
            columns: [{
                name: 'icon',
                displayName: '',
                width: 40,
                enableColumnMoving: false,
                enableColumnResizing: false,
                enableFiltering: false,
                pinnedLeft: true
            }, {
                name: 'object_string',
                displayName: 'object_string',
                typeName: 'WorkspaceObject',
                width: 300
            }, {
                name: 'object_desc',
                displayName: 'Description',
                typeName: 'WorkspaceObject',
                width: 300
            }, {
                name: 'last_mod_date',
                displayName: 'last_mod_date',
                typeName: 'WorkspaceObject',
                width: 300
            }, {
                name: 'owning_user',
                displayName: 'owning_user',
                typeName: 'WorkspaceObject',
                width: 300
            }]
        }
    };

    return exports;

} );